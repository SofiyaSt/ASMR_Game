RU: 
Автором текстурпака является _Sofiya_Star.
Текстурпак создан для популяризации настольной игры "Ковен", без претензий 
на авторство и права.
Его использование бесплатно и свободно для любых серверов и игроков.

Оригинальная настольная игра, правила и роли которой были использованы при
создании, называется "Ковен".

Настольная игра "Ковен" - это фентези мафия, в которой имеется 3 команды,
25 ролей, а также уникальные игровые механики. Подробнее ознакомиться с 
оригинальной версии игры вы можете на сайте студии "Игровая таверна"
(tavernagame.com).

В файле CMD_items.txt вы найдете список переименований для предметов и
игровых карточек.
Текстурпак работает за счет изменения nbt-тега CustomModelData.
Если вы планируете создавать предметы на сервере, необходимо установить
плагин для возможности указания CMD через наковальню.
Ссылка на такой плагин - https://modrinth.com/plugin/custommodeldata

===========================================================================

ENG: 
The author of the texture pack is _Sofiya_Star.
Texturpack was designed to promote the board game «Coven», without any 
claims to authorship or intellectual property rights.
Its use is free and free for any servers and players.

Original board game, the foundation of which was laid by the rules and 
characters, is known as «Coven». 

Coven is a fantasy mafia board game with 3 teams, 25 unique roles, and 
innovative game mechanics. For more information about the original version 
of the game, please visit the website of Igry Tavern (tavernagame.com)

In the file CMD_items.txt, you will find a list of item and game card
renames.
The texture pack works by modifying the CustomModelData NBT tag.
If you want to create items on the server, you will need to install a 
plugin that allows you to specify CMD via the anvil.
You can find this plugin here - https://modrinth.com/plugin/custommodeldata
